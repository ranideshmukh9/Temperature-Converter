package com.rd595344.temperatureconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    EditText user_temp;
    Button btn_convert;
    Spinner spinner;
    private final String[] names ={"Celsius","Fahrenheit","Kelvin"};
    private String temp_type="Celsius";
    TextView cel,faren,kelvin;
    LinearLayout layout_cel,layout_faren,layout_kelvin;

    private String input;
    private float value;

    private static final DecimalFormat decfor = new DecimalFormat("0.00");

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // finding and initialization the variables
        user_temp = findViewById(R.id.edit_temp);
        btn_convert = findViewById(R.id.btn_convert);
        spinner = findViewById(R.id.spinner);

        cel = findViewById(R.id.txt_cel);
        faren = findViewById(R.id.txt_faren);
        kelvin = findViewById(R.id.txt_kelvin);

        layout_cel= findViewById(R.id.layout_cel);
        layout_faren= findViewById(R.id.layout_faren);
        layout_kelvin= findViewById(R.id.layout_kelvin);

        //Working with spinner

        ArrayAdapter<String> list=new ArrayAdapter<>(MainActivity.this, R.layout.spinner_txt,names);
        list.setDropDownViewResource(R.layout.spinner_txt);
        spinner.setAdapter(list);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                temp_type = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // working with the main login
        btn_convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input = user_temp.getText().toString();
                if (TextUtils.isEmpty(input)){
                    Toast.makeText(MainActivity.this, "Please Enter Temperature", Toast.LENGTH_SHORT).show();
                }else {
                    value= Float.parseFloat(input);

                    if (temp_type=="Celsius"){
                        celToAnother(value);
                    }
                    else if (temp_type=="Fahrenheit") {
                        farenToAnother(value);
                    }
                    else {
                        kelvinToAnother(value);
                    }
                }
            }
        });

    }
    @SuppressLint("SetTextI18n")
    public void celToAnother(float value){
        layout_cel.setVisibility(View.GONE);
        layout_faren.setVisibility(View.VISIBLE);
        layout_kelvin.setVisibility(View.VISIBLE);
        float faren_val =((value*9.0f/5)+32);
        faren.setText(decfor.format(faren_val)+" F");
        kelvin.setText(value+273.15f+" K");
    }

    @SuppressLint("SetTextI18n")
    public void farenToAnother(float value){
        layout_faren.setVisibility(View.GONE);
        layout_cel.setVisibility(View.VISIBLE);
        layout_kelvin.setVisibility(View.VISIBLE);
        float cel_val =(value-32)*5/9;
        cel.setText(decfor.format(cel_val)+" C");
        kelvin.setText(decfor.format(cel_val+273.15f)+" K");
    }


    @SuppressLint("SetTextI18n")
    public void kelvinToAnother(float value){
        layout_kelvin.setVisibility(View.GONE);
        layout_faren.setVisibility(View.VISIBLE);
        layout_cel.setVisibility(View.VISIBLE);
        float faren_val =((value-273.15f)*9/5)+32;
        cel.setText(value-273.15f+" C");
        faren.setText(decfor.format(faren_val)+" F");
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}